package uk.stuart.championshifts;

import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.regex.*;

/** Strict parser: a failed or ambiguous parse is never an auto-accept. */
public final class OfferParser {
    private static final Pattern DATE = Pattern.compile("(?i)\\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b");
    private static final Pattern TIME = Pattern.compile("(?<![\\d.])(\\d{1,2})[.:](\\d{2})\\s*[-–—]\\s*(\\d{1,2})[.:](\\d{2})(?![\\d.])");
    private static final Pattern POSTCODE = Pattern.compile("(?i)\\b([A-Z]{1,2}\\d[A-Z\\d]?\\s*\\d[A-Z]{2})\\b");
    private static final Pattern NEED = Pattern.compile("(?i)\\bneed\\s+(?:\\d+\\s*x?\\s*|one\\s+|two\\s+)?crew\\b");
    private static final Pattern CLAIMED = Pattern.compile("(?i)\\b(sent to|covered|filled|sorted|cancelled|deleted)\\b");
    public record Offer(LocalDateTime start, LocalDateTime end, String postcode, String key) { }

    public static Optional<Offer> parse(String message, ZonedDateTime received) {
        if (message == null || !NEED.matcher(message).find() || CLAIMED.matcher(message).find()) return Optional.empty();
        if (message.indexOf('>') >= 0 || message.contains("@Stu")) return Optional.empty(); // directed/multiple posts: review
        Matcher time = TIME.matcher(message);
        if (!time.find()) return Optional.empty();
        int sh = Integer.parseInt(time.group(1)), sm = Integer.parseInt(time.group(2));
        int eh = Integer.parseInt(time.group(3)), em = Integer.parseInt(time.group(4));
        if (sh > 23 || eh > 23 || sm > 59 || em > 59 || time.find()) return Optional.empty();
        Matcher pc = POSTCODE.matcher(message);
        if (!pc.find()) return Optional.empty();
        String postcode = pc.group(1).toUpperCase(Locale.UK).replaceAll("\\s+", "");
        if (pc.find()) return Optional.empty();
        LocalDate date;
        Matcher dm = DATE.matcher(message);
        if (dm.find()) {
            int day = Integer.parseInt(dm.group(2));
            DayOfWeek dow = DayOfWeek.valueOf(dm.group(1).toUpperCase(Locale.UK));
            if (dm.find()) return Optional.empty();
            date = null;
            // Prefer the current month, otherwise the next month. Never infer dates more than 31 days away.
            for (int offset = 0; offset <= 1; offset++) {
                YearMonth ym = YearMonth.from(received).plusMonths(offset);
                if (day <= ym.lengthOfMonth()) {
                    LocalDate candidate = ym.atDay(day);
                    if (!candidate.isBefore(received.toLocalDate()) && candidate.getDayOfWeek() == dow
                            && candidate.isBefore(received.toLocalDate().plusDays(32))) {
                        if (date != null) return Optional.empty();
                        date = candidate;
                    }
                }
            }
            if (date == null) return Optional.empty();
        } else if (Pattern.compile("(?i)\\btonight\\b").matcher(message).find()) {
            date = received.toLocalDate();
        } else return Optional.empty();
        LocalDateTime start = date.atTime(sh, sm);
        LocalDateTime end = date.atTime(eh, em);
        if (!end.isAfter(start)) end = end.plusDays(1);
        if (!start.atZone(received.getZone()).isAfter(received) || end.isAfter(start.plusHours(14))) return Optional.empty();
        String key = start + "/" + end + "/" + postcode;
        return Optional.of(new Offer(start, end, postcode, key));
    }
    private OfferParser() { }
}
