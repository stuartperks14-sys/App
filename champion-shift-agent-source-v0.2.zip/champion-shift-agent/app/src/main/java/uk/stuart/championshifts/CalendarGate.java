package uk.stuart.championshifts;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import java.time.*;
import java.util.*;

/** Fail closed: only a readable, visible, synced Google calendar can establish availability. */
final class CalendarGate {
    static boolean clear(Context context, OfferParser.Offer offer) {
        if (context.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return false;
        Set<Long> ids = new HashSet<>();
        try (Cursor c = context.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,
                new String[]{"_id", "account_type", "visible", "sync_events"}, null, null, null)) {
            if (c == null) return false;
            while (c.moveToNext()) if ("com.google".equals(c.getString(1)) && c.getInt(2) == 1 && c.getInt(3) == 1) ids.add(c.getLong(0));
        } catch (Exception ignored) { return false; }
        if (ids.isEmpty()) return false;
        ZoneId zone = ZoneId.of("Europe/London");
        // A job anywhere on its starting day blocks another automatic offer, as Champion requested.
        long windowStart = offer.start().toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli();
        long windowEnd = offer.end().toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        Uri.Builder uri = CalendarContract.Instances.CONTENT_URI.buildUpon();
        android.content.ContentUris.appendId(uri, windowStart);
        android.content.ContentUris.appendId(uri, windowEnd);
        try (Cursor c = context.getContentResolver().query(uri.build(),
                new String[]{"calendar_id", "begin", "end", "availability"}, null, null, null)) {
            if (c == null) return false;
            while (c.moveToNext()) {
                if (!ids.contains(c.getLong(0)) || c.getInt(3) == CalendarContract.Events.AVAILABILITY_FREE) continue;
                long begin = c.getLong(1), end = c.getLong(2);
                // Busy on start day, or overlapping an overnight shift on the next day.
                if (begin < windowEnd && end > windowStart &&
                        (begin < offer.start().toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
                         || begin < offer.end().atZone(zone).toInstant().toEpochMilli()
                            && end > offer.start().atZone(zone).toInstant().toEpochMilli())) return false;
            }
            // Preserve one whole weekend day free. Check the other day in the same weekend.
            DayOfWeek day = offer.start().getDayOfWeek();
            if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
                LocalDate other = offer.start().toLocalDate().plusDays(day == DayOfWeek.SATURDAY ? 1 : -1);
                long from = other.atStartOfDay(zone).toInstant().toEpochMilli();
                long to = other.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
                Uri.Builder otherUri = CalendarContract.Instances.CONTENT_URI.buildUpon();
                android.content.ContentUris.appendId(otherUri, from);
                android.content.ContentUris.appendId(otherUri, to);
                try (Cursor weekend = context.getContentResolver().query(otherUri.build(),
                        new String[]{"calendar_id", "begin", "end", "availability"}, null, null, null)) {
                    if (weekend == null) return false;
                    while (weekend.moveToNext()) if (ids.contains(weekend.getLong(0))
                            && weekend.getInt(3) != CalendarContract.Events.AVAILABILITY_FREE
                            && weekend.getLong(1) < to && weekend.getLong(2) > from) return false;
                }
            }
            return true;
        } catch (Exception ignored) { return false; }
    }
    private CalendarGate() { }
}
