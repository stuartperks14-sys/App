package uk.stuart.championshifts;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    private TextView activity;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(36, 48, 36, 24);
        layout.setOrientation(LinearLayout.VERTICAL);
        TextView explanation = new TextView(this);
        explanation.setText("Champion Shift Agent\n\nWatches WhatsApp notifications from Champions and Champion Leaders. It replies only to one clear new offer when your visible Google calendars show no busy events that day. Quotes, several shifts, direct tags and unclear dates are skipped. Keep Google Calendar up to date.\n\nStart in review mode and test with real notifications before arming automatic replies.");
        layout.addView(explanation);
        Button calendar = new Button(this);
        calendar.setText("Allow calendar access");
        calendar.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.READ_CALENDAR}, 7));
        layout.addView(calendar);
        Button notifications = new Button(this);
        notifications.setText("Allow notification access");
        notifications.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        layout.addView(notifications);
        Switch toggle = new Switch(this);
        toggle.setText("Automatically reply yes to clear offers");
        toggle.setChecked(getPreferences(MODE_PRIVATE).getBoolean("armed", false));
        toggle.setOnCheckedChangeListener((button, checked) -> {
            if (checked && checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                button.setChecked(false);
                Toast.makeText(this, "Allow calendar access first", Toast.LENGTH_LONG).show();
            } else getPreferences(MODE_PRIVATE).edit().putBoolean("armed", checked).apply();
        });
        layout.addView(toggle);
        status = new TextView(this);
        status.setPadding(0, 32, 0, 0);
        status.setText("Latest result appears here when you reopen the app.");
        layout.addView(status);
        TextView heading = new TextView(this);
        heading.setPadding(0, 40, 0, 12);
        heading.setTextSize(20);
        heading.setText("Activity log");
        layout.addView(heading);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = new Button(this);
        copy.setText("Copy log");
        copy.setOnClickListener(v -> {
            String text = ActivityLog.display(this);
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                    .setPrimaryClip(ClipData.newPlainText("Champion Shift Agent log", text));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        });
        actions.addView(copy, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button clear = new Button(this);
        clear.setText("Clear log");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Clear activity log?")
                .setMessage("This permanently removes all saved activity entries.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (dialog, which) -> {
                    ActivityLog.clear(this);
                    refresh();
                }).show());
        actions.addView(clear, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        layout.addView(actions);
        activity = new TextView(this);
        activity.setTextIsSelectable(true);
        activity.setPadding(0, 16, 0, 40);
        layout.addView(activity);
        scroll.addView(layout);
        setContentView(scroll);
    }
    @Override protected void onResume() {
        super.onResume();
        refresh();
    }
    private void refresh() {
        status.setText("Latest result: " + getPreferences(MODE_PRIVATE).getString("last", "No offer processed yet"));
        activity.setText(ActivityLog.display(this));
    }
}
