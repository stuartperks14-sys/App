package uk.stuart.championshifts;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.service.notification.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

public class ShiftListener extends NotificationListenerService {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final Set<String> GROUPS = new HashSet<>(Arrays.asList("Champions", "Champion Leaders"));

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!"com.whatsapp".equals(sbn.getPackageName()) || sbn.getNotification().extras == null) return;
        Bundle e = sbn.getNotification().extras;
        // Require WhatsApp to expose an exact conversation title. A generic summary is never sufficient.
        String group = e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE, "").toString().trim();
        if (!GROUPS.contains(group) || (sbn.getNotification().flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        CharSequence raw = e.getCharSequence(Notification.EXTRA_TEXT);
        if (raw == null) return;
        String message = raw.toString();
        worker.execute(() -> process(sbn, group, message));
    }

    private void process(StatusBarNotification sbn, String group, String message) {
        // Activity.getPreferences() uses MainActivity's private file.
        android.content.SharedPreferences prefs = getSharedPreferences("MainActivity", MODE_PRIVATE);
        ZonedDateTime received = Instant.ofEpochMilli(sbn.getPostTime()).atZone(ZoneId.of("Europe/London"));
        if (message.startsWith("You:")) {
            ActivityLog.add(this, sbn.getPostTime(), group, message, null, "Skipped", "Your own outgoing message", false, false);
            return;
        }
        if (message.contains("\n")) {
            ActivityLog.add(this, sbn.getPostTime(), group, message, null, "Skipped", "WhatsApp supplied a combined or multiline notification", false, false);
            prefs.edit().putString("last", "Skipped combined WhatsApp notification").apply();
            return;
        }
        Optional<OfferParser.Offer> parsed = OfferParser.parse(message, received);
        if (parsed.isEmpty()) {
            ActivityLog.add(this, sbn.getPostTime(), group, message, null, "Skipped", "Unclear, non-offer, direct tag, claimed job, or unsupported format", false, false);
            prefs.edit().putString("last", "Skipped unclear or non-offer message").apply(); return;
        }
        OfferParser.Offer offer = parsed.get();
        String key = offer.key();
        long now = System.currentTimeMillis();
        if (prefs.getLong("seen:" + key, 0) > now - TimeUnit.DAYS.toMillis(8)) {
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Duplicate", "This shift was already processed within eight days", false, false);
            return;
        }
        DayOfWeek dow = offer.start().getDayOfWeek();
        if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
            String other = offer.start().toLocalDate().plusDays(dow == DayOfWeek.SATURDAY ? 1 : -1).toString();
            if (prefs.getLong("weekend:" + other, 0) > now - TimeUnit.DAYS.toMillis(8)) {
                prefs.edit().putString("last", "Review " + key + ": keep one weekend day free").apply();
                ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Review", "Keeping one weekend day free", false, false);
                return;
            }
        }
        if (!CalendarGate.clear(this, offer)) {
            prefs.edit().putString("last", "Review " + key + ": calendar busy or unavailable").apply();
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Calendar conflict", "Calendar is busy or could not be checked", false, false); return;
        }
        if (!prefs.getBoolean("armed", false)) {
            prefs.edit().putString("last", "Review available offer " + key).apply();
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Available — review mode", "Calendar is clear but automatic replies are off", false, false); return;
        }
        // Recheck the original notification: a job deleted while checking the calendar must be skipped.
        boolean active = false;
        try { for (StatusBarNotification current : getActiveNotifications())
            if (current.getKey().equals(sbn.getKey()) && current.getPostTime() == sbn.getPostTime()) {
                CharSequence latest = current.getNotification().extras.getCharSequence(Notification.EXTRA_TEXT);
                if (latest != null && message.contentEquals(latest)) active = true;
            }
        } catch (Exception ignored) {
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Error", "Could not recheck the WhatsApp notification", false, false); return;
        }
        if (!active) {
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Skipped", "Notification disappeared before replying", false, false); return;
        }
        Notification.Action action = null;
        RemoteInput input = null;
        if (sbn.getNotification().actions != null) for (Notification.Action a : sbn.getNotification().actions) {
            if (a.getRemoteInputs() == null) continue;
            for (RemoteInput r : a.getRemoteInputs()) if (r.getAllowFreeFormInput()) { action = a; input = r; break; }
            if (action != null) break;
        }
        if (action == null || input == null) {
            prefs.edit().putString("last", "Review " + key + ": WhatsApp reply unavailable").apply();
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Reply unavailable", "WhatsApp did not provide a quick-reply action", false, false); return;
        }
        // Reserve before sending to prevent duplicate replies from mirrored offers in the two groups.
        prefs.edit().putLong("seen:" + key, now).commit();
        String weekendKey = (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY)
                ? "weekend:" + offer.start().toLocalDate() : null;
        if (weekendKey != null) prefs.edit().putLong(weekendKey, now).commit();
        try {
            Intent intent = new Intent();
            Bundle reply = new Bundle();
            reply.putCharSequence(input.getResultKey(), "Yes, I can do that");
            RemoteInput.addResultsToIntent(new RemoteInput[]{input}, intent, reply);
            action.actionIntent.send(this, 0, intent);
            prefs.edit().putString("last", "Reply sent for " + key + " (check WhatsApp for delivery)").apply();
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Replied Yes", "Calendar clear and automatic replies enabled", true, true);
        } catch (Exception ex) {
            android.content.SharedPreferences.Editor edit = prefs.edit().remove("seen:" + key).putString("last", "Reply failed for " + key);
            if (weekendKey != null) edit.remove(weekendKey);
            edit.apply();
            ActivityLog.add(this, sbn.getPostTime(), group, message, offer, "Reply failed", "WhatsApp rejected or could not send the quick reply", true, false);
        }
    }
    @Override public void onDestroy() { worker.shutdown(); super.onDestroy(); }
}
