package uk.stuart.championshifts;

import android.content.*;
import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

/** Small persistent, device-only activity log. */
public final class ActivityLog {
    private static final String PREFS = "MainActivity";
    private static final String KEY = "activity_log";
    private static final int LIMIT = 500;

    public static synchronized void add(Context context, long receivedAt, String group,
            String message, OfferParser.Offer offer, String result, String reason,
            boolean replyAttempted, boolean replySent) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(prefs.getString(KEY, "[]"));
            JSONObject item = new JSONObject();
            item.put("receivedAt", receivedAt);
            item.put("group", group == null ? "" : group);
            item.put("message", message == null ? "" : message);
            item.put("result", result);
            item.put("reason", reason);
            item.put("replyAttempted", replyAttempted);
            item.put("replySent", replySent);
            if (offer != null) {
                item.put("start", offer.start().toString());
                item.put("end", offer.end().toString());
                item.put("postcode", offer.postcode());
            }
            JSONArray updated = new JSONArray();
            updated.put(item);
            for (int i = 0; i < old.length() && updated.length() < LIMIT; i++) updated.put(old.get(i));
            prefs.edit().putString(KEY, updated.toString()).apply();
        } catch (JSONException ignored) { }
    }

    public static String display(Context context) {
        try {
            JSONArray items = new JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY, "[]"));
            if (items.length() == 0) return "No activity recorded yet.";
            StringBuilder out = new StringBuilder();
            DateTimeFormatter stamp = DateTimeFormatter.ofPattern("dd MMM HH:mm");
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.getJSONObject(i);
                ZonedDateTime when = Instant.ofEpochMilli(item.optLong("receivedAt"))
                        .atZone(ZoneId.of("Europe/London"));
                if (i > 0) out.append("\n\n────────────────────\n\n");
                out.append(stamp.format(when)).append("  •  ").append(item.optString("group"));
                out.append("\n").append(item.optString("result"));
                String start = item.optString("start");
                if (!start.isEmpty()) out.append("\nShift: ").append(start.replace('T', ' '))
                        .append(" – ").append(item.optString("end").replace('T', ' '))
                        .append("  ").append(item.optString("postcode"));
                out.append("\nReason: ").append(item.optString("reason"));
                out.append("\nMessage: ").append(item.optString("message"));
            }
            return out.toString();
        } catch (Exception ex) { return "The activity log could not be read."; }
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    private ActivityLog() { }
}
