# Champion Shift Agent — Android prototype

This source project watches **new WhatsApp notifications** from the exact groups `Champions` and `Champion Leaders`. It parses one clear shift offer, checks locally synced, visible Google calendars, and can reply `Yes, I can do that` using WhatsApp's inline notification reply. It does not connect to WhatsApp's servers or give a remote service your messages or calendar.

## Status

Source prototype. **No APK has been built or installed and notification delivery has not been tested on Stuart's phone. Do not rely on it for shifts yet.** The environment used to create it has no Android SDK or Gradle, so the Android project has not been compiled. Android Studio with Android SDK 35 and JDK 17 is needed to build it, then an on-device trial must verify the two group titles and WhatsApp's notification format.

## Rules in this prototype

- Exact conversation title must be `Champions` or `Champion Leaders`; WhatsApp must deliver a notification with its inline reply action.
- Message must have `Need ... crew`, one time range, one postcode, and either `TONIGHT` or a weekday plus day number (within the current or following month and within 31 days). Overnight finishes are supported. It will skip messages that arrived after the offered start time.
- Multiple times, ambiguous dates, claimed or cancelled posts, and direct `@Stu` mentions go to review. Quotes and group summary notifications are not accepted. If the notification disappears or changes before replying, it stops.
- Every visible, syncing Google calendar on the device is checked. Busy events on the offer's starting day block automatic reply; an overnight shift is also checked against next-day overlapping events. Events marked **Free** do not block. A weekend shift is blocked if the other weekend day has a busy event; an earlier automatic weekend reply is also remembered.
- Mirrored offers in the two groups are deduplicated by start, end and postcode. The agent remembers a sent reply for eight days. This is a reply to an offer, **not confirmation of a booking**. Add confirmed work to Google Calendar promptly. Incorrectly marked `Free` events or unsynced/missing calendar entries cannot protect your availability.
- On-device switch starts **off**. Allow calendar and notification access, keep WhatsApp notifications enabled for both groups, then test with the switch off first. Only switch on after comparing real incoming offers against the app's latest result. Check WhatsApp for actual delivery after any attempted reply. Android and WhatsApp may alter notification format or reply availability.

## Build and install

1. Open this folder as a project in Android Studio. Install SDK 35 and JDK 17 if prompted; sync Gradle.
2. Build an APK and install it on Stuart's Android phone (Android 14 or later). The app needs no network access itself.
3. Open the app; grant Calendar access and Notification access through Android Settings. Confirm Google Calendar is syncing the calendars containing both work shifts and personal busy time.
4. Keep the switch off for the first real offers. Open the app after an offer to inspect its last result. The notification listener only sees notifications received after it has been granted access.
5. When tested, arm the switch. Disarm it whenever the calendar is out of date.

## Test messages from the supplied screenshots

| Example | Expected |
| --- | --- |
| `Need 1crew Wednesday 23rd 08.00-10.00 The Langham W1B 1JA` | One offer if received before start and the calendar is clear. |
| `Need 2crew TONIGHT 22.00-02.00 Hackney Church E5 0PD` | One overnight offer if before 22:00. |
| Same offer repeated in both chats | One reply at most. |
| `Sent to @Steve` quoting a prior offer | No reply. |
| Wednesday with three separate shift times and `@Stu` | Review; no automatic reply. |
| `This message was deleted` | No reply. |

## Remaining device checks

The critical unknown is what WhatsApp puts in `Notification.EXTRA_CONVERSATION_TITLE` and `Notification.EXTRA_TEXT` on Stuart's Samsung phone. If WhatsApp does not expose the exact group name and the full single message, the listener fails closed and needs adjustment based on a test notification. Samsung battery management can also stop the listener or delay notifications. Calendar sync freshness is not detectable from this prototype. There is no guarantee an offer is still open by the time a reply arrives.
