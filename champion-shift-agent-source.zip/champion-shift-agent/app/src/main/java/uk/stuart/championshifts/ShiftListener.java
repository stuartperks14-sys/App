package uk.stuart.championshifts;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.service.notification.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

public class ShiftListener extends NotificationListenerService {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final Set<String> GROUPS = new HashSet<>(Arrays.asList("Champions", "Champion Leaders"));

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!"com.whatsapp".equals(sbn.getPackageName()) || sbn.getNotification().extras == null) return;
        Bundle e = sbn.getNotification().extras;
        // Require WhatsApp to expose an exact conversation title. A generic summary is never sufficient.
        String group = e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE, "").toString().trim();
        if (!GROUPS.contains(group) || (sbn.getNotification().flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        CharSequence raw = e.getCharSequence(Notification.EXTRA_TEXT);
        if (raw == null) return;
        String message = raw.toString();
        if (message.contains("\n") || message.startsWith("You:")) return;
        worker.execute(() -> process(sbn, message));
    }

    private void process(StatusBarNotification sbn, String message) {
        // Activity.getPreferences() uses MainActivity's private file.
        android.content.SharedPreferences prefs = getSharedPreferences("MainActivity", MODE_PRIVATE);
        ZonedDateTime received = Instant.ofEpochMilli(sbn.getPostTime()).atZone(ZoneId.of("Europe/London"));
        Optional<OfferParser.Offer> parsed = OfferParser.parse(message, received);
        if (parsed.isEmpty()) { prefs.edit().putString("last", "Skipped unclear or non-offer message").apply(); return; }
        OfferParser.Offer offer = parsed.get();
        String key = offer.key();
        long now = System.currentTimeMillis();
        if (prefs.getLong("seen:" + key, 0) > now - TimeUnit.DAYS.toMillis(8)) return;
        DayOfWeek dow = offer.start().getDayOfWeek();
        if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
            String other = offer.start().toLocalDate().plusDays(dow == DayOfWeek.SATURDAY ? 1 : -1).toString();
            if (prefs.getLong("weekend:" + other, 0) > now - TimeUnit.DAYS.toMillis(8)) {
                prefs.edit().putString("last", "Review " + key + ": keep one weekend day free").apply();
                return;
            }
        }
        if (!CalendarGate.clear(this, offer)) { prefs.edit().putString("last", "Review " + key + ": calendar busy or unavailable").apply(); return; }
        if (!prefs.getBoolean("armed", false)) { prefs.edit().putString("last", "Review available offer " + key).apply(); return; }
        // Recheck the original notification: a job deleted while checking the calendar must be skipped.
        boolean active = false;
        try { for (StatusBarNotification current : getActiveNotifications())
            if (current.getKey().equals(sbn.getKey()) && current.getPostTime() == sbn.getPostTime()) {
                CharSequence latest = current.getNotification().extras.getCharSequence(Notification.EXTRA_TEXT);
                if (latest != null && message.contentEquals(latest)) active = true;
            }
        } catch (Exception ignored) { return; }
        if (!active) return;
        Notification.Action action = null;
        RemoteInput input = null;
        if (sbn.getNotification().actions != null) for (Notification.Action a : sbn.getNotification().actions) {
            if (a.getRemoteInputs() == null) continue;
            for (RemoteInput r : a.getRemoteInputs()) if (r.getAllowFreeFormInput()) { action = a; input = r; break; }
            if (action != null) break;
        }
        if (action == null || input == null) { prefs.edit().putString("last", "Review " + key + ": WhatsApp reply unavailable").apply(); return; }
        // Reserve before sending to prevent duplicate replies from mirrored offers in the two groups.
        prefs.edit().putLong("seen:" + key, now).commit();
        String weekendKey = (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY)
                ? "weekend:" + offer.start().toLocalDate() : null;
        if (weekendKey != null) prefs.edit().putLong(weekendKey, now).commit();
        try {
            Intent intent = new Intent();
            Bundle reply = new Bundle();
            reply.putCharSequence(input.getResultKey(), "Yes, I can do that");
            RemoteInput.addResultsToIntent(new RemoteInput[]{input}, intent, reply);
            action.actionIntent.send(this, 0, intent);
            prefs.edit().putString("last", "Reply sent for " + key + " (check WhatsApp for delivery)").apply();
        } catch (Exception ex) {
            android.content.SharedPreferences.Editor edit = prefs.edit().remove("seen:" + key).putString("last", "Reply failed for " + key);
            if (weekendKey != null) edit.remove(weekendKey);
            edit.apply();
        }
    }
    @Override public void onDestroy() { worker.shutdown(); super.onDestroy(); }
}
