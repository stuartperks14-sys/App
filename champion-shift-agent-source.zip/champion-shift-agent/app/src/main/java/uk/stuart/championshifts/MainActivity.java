package uk.stuart.championshifts;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(36, 48, 36, 24);
        layout.setOrientation(LinearLayout.VERTICAL);
        TextView explanation = new TextView(this);
        explanation.setText("Champion Shift Agent\n\nWatches WhatsApp notifications from Champions and Champion Leaders. It replies only to one clear new offer when your visible Google calendars show no busy events that day. Quotes, several shifts, direct tags and unclear dates are skipped. Keep Google Calendar up to date.\n\nStart in review mode and test with real notifications before arming automatic replies.");
        layout.addView(explanation);
        Button calendar = new Button(this);
        calendar.setText("Allow calendar access");
        calendar.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.READ_CALENDAR}, 7));
        layout.addView(calendar);
        Button notifications = new Button(this);
        notifications.setText("Allow notification access");
        notifications.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        layout.addView(notifications);
        Switch toggle = new Switch(this);
        toggle.setText("Automatically reply yes to clear offers");
        toggle.setChecked(getPreferences(MODE_PRIVATE).getBoolean("armed", false));
        toggle.setOnCheckedChangeListener((button, checked) -> {
            if (checked && checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                button.setChecked(false);
                Toast.makeText(this, "Allow calendar access first", Toast.LENGTH_LONG).show();
            } else getPreferences(MODE_PRIVATE).edit().putBoolean("armed", checked).apply();
        });
        layout.addView(toggle);
        TextView status = new TextView(this);
        status.setPadding(0, 32, 0, 0);
        status.setText("Latest result appears here when you reopen the app.");
        layout.addView(status);
        setContentView(layout);
    }
    @Override protected void onResume() {
        super.onResume();
        // Reopening the app refreshes the last result; the service runs separately.
        LinearLayout layout = (LinearLayout) ((android.view.ViewGroup) findViewById(android.R.id.content)).getChildAt(0);
        TextView status = (TextView) layout.getChildAt(layout.getChildCount() - 1);
        status.setText("Latest result: " + getPreferences(MODE_PRIVATE).getString("last", "No offer processed yet"));
    }
}
